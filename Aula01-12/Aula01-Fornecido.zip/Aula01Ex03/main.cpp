#include <iostream>

using namespace std;

double calcularConsumoDoVentilador (int velocidade[],
                                    int horas[],
                                    int quantidadeDeValores) {
  // IMPLEMENTAR FUNCAO
  return 0;
}

// A FUNCAO MAIN NAO DEVE SER SUBMETIDA
int main() {
  int velocidades[4] = {2, 3, 2, 0};
  int horas[4] = {1, 2, 4, 2};
  cout << calcularConsumoDoVentilador (velocidades, horas,
                                       4) << endl;
  // MAIS TESTES DEVEM SER FEITOS
}
