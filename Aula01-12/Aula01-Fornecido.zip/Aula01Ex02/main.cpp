#include <iostream>

using namespace std;

int acionarVentilador (bool presencaDetectada,
                       int temperatura) {
  // IMPLEMENTAR FUNCAO
  return 0;
}

// A FUNCAO MAIN NAO DEVE SER SUBMETIDA
int main() {
  cout << acionarVentilador (true, 15) << endl;
  cout << acionarVentilador (false, 50) << endl;
  // MAIS TESTES DEVEM SER FEITOS
}
