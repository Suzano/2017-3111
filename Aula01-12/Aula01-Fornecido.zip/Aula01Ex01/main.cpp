#include <iostream>

using namespace std;

double calcularConsumoDaLampada (int tipo, int horas) {
  // IMPLEMENTAR FUNCAO
  return 0;
}

// A FUNCAO MAIN NAO DEVE SER SUBMETIDA
int main() {
  cout << calcularConsumoDaLampada (1, 10) << endl;
  cout << calcularConsumoDaLampada (2, 20) << endl;
  // MAIS TESTES DEVEM SER FEITOS
}
